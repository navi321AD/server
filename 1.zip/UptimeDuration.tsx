import React from 'react'; // Импортирование React

// Компонент, который принимает время работы (uptime) в секундах и отображает его в удобном формате
export default ({ uptime }: { uptime: number }) => {
    const days = Math.floor(uptime / (24 * 60 * 60)); // Вычисление количества дней
    const hours = Math.floor((Math.floor(uptime) / 60 / 60) % 24); // Вычисление количества часов
    const remainder = Math.floor(uptime - hours * 60 * 60); // Остаток времени после учета часов
    const minutes = Math.floor((remainder / 60) % 60); // Вычисление количества минут
    const seconds = remainder % 60; // Остаток времени в секундах

    // Если есть дни, отображаем дни, часы и минуты
    if (days > 0) {
        return (
            <>
                {days}d {hours}h {minutes}m
            </>
        );
    }

    // Если нет дней, отображаем часы, минуты и секунды
    return (
        <>
            {hours}h {minutes}m {seconds}s
        </>
    );
};
