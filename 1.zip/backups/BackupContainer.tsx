import tw from 'twin.macro';
import useFlash from '@/plugins/useFlash';
import Can from '@/components/elements/Can';
import { ServerContext } from '@/state/server';
import Spinner from '@/components/elements/Spinner';
import Pagination from '@/components/elements/Pagination';
import BackupRow from '@/components/server/backups/BackupRow';
import React, { useContext, useEffect, useState } from 'react';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import CreateBackupButton from '@/components/server/backups/CreateBackupButton';
import getServerBackups, { Context as ServerBackupContext } from '@/api/swr/getServerBackups';

// Основной контейнер для отображения бэкапов
const BackupContainer = () => {
    const { page, setPage } = useContext(ServerBackupContext); // Текущая страница и функция для её смены
    const { clearFlashes, clearAndAddHttpError } = useFlash(); // Уведомления об ошибках
    const { data: backups, error, isValidating } = getServerBackups(); // Получение данных о бэкапах

    // Лимит на количество бэкапов для сервера
    const backupLimit = ServerContext.useStoreState((state) => state.server.data!.featureLimits.backups);

    useEffect(() => {
        if (!error) {
            clearFlashes('backups'); // Очищаем сообщения, если нет ошибок
            return;
        }

        // Добавляем ошибку, если она появилась
        clearAndAddHttpError({ error, key: 'backups' });
    }, [error]);

    if (!backups || (error && isValidating)) {
        return <Spinner size={'large'} centered />; // Показываем спиннер, если данные загружаются
    }

    return (
        <ServerContentBlock title={'Резервные копии'}> {/* Заголовок блока */}
            <FlashMessageRender byKey={'backups'} css={tw`mb-4`} /> {/* Отображение уведомлений */}
            <Pagination data={backups} onPageSelect={setPage}> {/* Пагинация по бэкапам */}
                {({ items }) =>
                    !items.length ? (
                        // Если нет бэкапов и лимит на их создание исчерпан, сообщение не выводится
                        !backupLimit ? null : (
                            <p css={tw`text-center text-sm text-neutral-300`}>
                                {page > 1
                                    ? "Похоже, что мы показали все резервные копии, попробуйте вернуться на предыдущую страницу."
                                    : 'Похоже, что для этого сервера нет сохраненных резервных копий.'}
                            </p>
                        )
                    ) : (
                        items.map((backup, index) => (
                            <BackupRow key={backup.uuid} backup={backup} css={index > 0 ? tw`mt-2` : undefined} />
                        ))
                    )
                }
            </Pagination>
            {backupLimit === 0 && (
                <p css={tw`text-center text-sm text-neutral-300`}>
                    Резервные копии не могут быть созданы для этого сервера, так как лимит установлен на 0.
                </p>
            )}
            <Can action={'backup.create'}>
                <div css={tw`mt-6 sm:flex items-center justify-end`}>
                    {backupLimit > 0 && backups.backupCount > 0 && (
                        <p css={tw`text-sm text-neutral-300 mb-4 sm:mr-6 sm:mb-0`}>
                            Создано {backups.backupCount} из {backupLimit} резервных копий для этого сервера.
                        </p>
                    )}
                    {backupLimit > 0 && backupLimit > backups.backupCount && (
                        <CreateBackupButton css={tw`w-full sm:w-auto`} /> {/* Кнопка создания бэкапа */}
                    )}
                </div>
            </Can>
        </ServerContentBlock>
    );
};

export default () => {
    const [page, setPage] = useState<number>(1); // Управление состоянием страницы
    return (
        <ServerBackupContext.Provider value={{ page, setPage }}>
            <BackupContainer />
        </ServerBackupContext.Provider>
    );
};
