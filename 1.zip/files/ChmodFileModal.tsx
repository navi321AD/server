import { fileBitsToString } from '@/helpers'; // Импортируем функцию для преобразования бит в строку
import useFileManagerSwr from '@/plugins/useFileManagerSwr'; // Импортируем хук для работы с файловым менеджером
import React from 'react';
import Modal, { RequiredModalProps } from '@/components/elements/Modal'; // Импортируем модальное окно
import { Form, Formik, FormikHelpers } from 'formik'; // Импортируем компоненты для работы с формами
import Field from '@/components/elements/Field'; // Импортируем компонент поля формы
import chmodFiles from '@/api/server/files/chmodFiles'; // Импортируем функцию для изменения прав на файлы
import { ServerContext } from '@/state/server'; // Импортируем контекст сервера
import tw from 'twin.macro'; // Импортируем библиотеку для стилизации
import Button from '@/components/elements/Button'; // Импортируем компонент кнопки
import useFlash from '@/plugins/useFlash'; // Импортируем хук для работы с сообщениями

interface FormikValues {
    mode: string; // Тип значения для формы
}

interface File {
    file: string; // Имя файла
    mode: string; // Режим файла
}

type OwnProps = RequiredModalProps & { files: File[] }; // Определяем тип собственных свойств

const ChmodFileModal = ({ files, ...props }: OwnProps) => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid); // Получаем UUID сервера
    const { mutate } = useFileManagerSwr(); // Получаем функцию для обновления состояния файлов
    const { clearFlashes, clearAndAddHttpError } = useFlash(); // Получаем функции для управления сообщениями
    const directory = ServerContext.useStoreState((state) => state.files.directory); // Получаем текущую директорию
    const setSelectedFiles = ServerContext.useStoreActions((actions) => actions.files.setSelectedFiles); // Получаем функцию для установки выбранных файлов

    const submit = ({ mode }: FormikValues, { setSubmitting }: FormikHelpers<FormikValues>) => {
        clearFlashes('files'); // Очищаем сообщения для файлов

        mutate(
            (data) =>
                data.map((f) =>
                    f.name === files[0].file ? { ...f, mode: fileBitsToString(mode, !f.isFile), modeBits: mode } : f
                ),
            false
        );

        const data = files.map((f) => ({ file: f.file, mode: mode })); // Подготавливаем данные для обновления

        chmodFiles(uuid, directory, data) // Вызываем функцию для изменения прав на файлы
            .then((): Promise<any> => (files.length > 0 ? mutate() : Promise.resolve())) // Обновляем состояние после изменения
            .then(() => setSelectedFiles([])) // Сбрасываем выбранные файлы
            .catch((error) => {
                mutate(); // Обновляем состояние в случае ошибки
                setSubmitting(false); // Устанавливаем состояние загрузки в false
                clearAndAddHttpError({ key: 'files', error }); // Добавляем сообщение об ошибке
            })
            .then(() => props.onDismissed()); // Закрываем модальное окно
    };

    return (
        <Formik onSubmit={submit} initialValues={{ mode: files.length > 1 ? '' : files[0].mode || '' }}>
            {({ isSubmitting }) => (
                <Modal {...props} dismissable={!isSubmitting} showSpinnerOverlay={isSubmitting}>
                    <Form css={tw`m-0`}>
                        <div css={tw`flex flex-wrap items-end`}>
                            <div css={tw`w-full sm:flex-1 sm:mr-4`}>
                                <Field type={'string'} id={'file_mode'} name={'mode'} label={'Режим файла'} autoFocus />
                            </div>
                            <div css={tw`w-full sm:w-auto mt-4 sm:mt-0`}>
                                <Button css={tw`w-full`}>Обновить</Button>
                            </div>
                        </div>
                    </Form>
                </Modal>
            )}
        </Formik>
    );
};

export default ChmodFileModal; // Экспортируем компонент
