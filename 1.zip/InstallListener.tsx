import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { ServerContext } from '@/state/server';
import { SocketEvent } from '@/components/server/events';
import { mutate } from 'swr';
import { getDirectorySwrKey } from '@/plugins/useFileManagerSwr';

const InstallListener = () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid); // Получение UUID сервера
    const getServer = ServerContext.useStoreActions((actions) => actions.server.getServer); // Действие для получения информации о сервере
    const setServerFromState = ServerContext.useStoreActions((actions) => actions.server.setServerFromState); // Действие для обновления состояния сервера

    // Подписка на событие завершения восстановления из резервной копии
    useWebsocketEvent(SocketEvent.BACKUP_RESTORE_COMPLETED, () => {
        mutate(getDirectorySwrKey(uuid, '/'), undefined); // Обновление данных в кэше
        setServerFromState((s) => ({ ...s, status: null })); // Сброс статуса сервера
    });

    // Подписка на событие завершения установки и получение обновленной информации о сервере
    useWebsocketEvent(SocketEvent.INSTALL_COMPLETED, () => {
        getServer(uuid).catch((error) => console.error(error)); // Логирование ошибок при получении информации о сервере
    });

    // Подписка на событие начала установки и обновление состояния
    useWebsocketEvent(SocketEvent.INSTALL_STARTED, () => {
        setServerFromState((s) => ({ ...s, status: 'installing' })); // Установка статуса в 'installing'
    });

    return null; // Компонент ничего не рендерит
};

export default InstallListener; // Экспорт компонента
