export enum SocketEvent {
    DAEMON_MESSAGE = 'daemon message', // Сообщение демона
    DAEMON_ERROR = 'daemon error', // Ошибка демона
    INSTALL_OUTPUT = 'install output', // Вывод установки
    INSTALL_STARTED = 'install started', // Установка начата
    INSTALL_COMPLETED = 'install completed', // Установка завершена
    CONSOLE_OUTPUT = 'console output', // Вывод консоли
    STATUS = 'status', // Статус
    STATS = 'stats', // Статистика
    TRANSFER_LOGS = 'transfer logs', // Логи передачи
    TRANSFER_STATUS = 'transfer status', // Статус передачи
    BACKUP_COMPLETED = 'backup completed', // Резервное копирование завершено
    BACKUP_RESTORE_COMPLETED = 'backup restore completed', // Восстановление из резервной копии завершено
}

export enum SocketRequest {
    SEND_LOGS = 'send logs', // Отправить логи
    SEND_STATS = 'send stats', // Отправить статистику
    SET_STATE = 'set state', // Установить состояние
}
