import React, { memo, useState } from 'react';
import { ServerEggVariable } from '@/api/server/types';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import { usePermissions } from '@/plugins/usePermissions';
import InputSpinner from '@/components/elements/InputSpinner';
import Input from '@/components/elements/Input';
import Switch from '@/components/elements/Switch';
import { debounce } from 'debounce';
import updateStartupVariable from '@/api/server/updateStartupVariable';
import useFlash from '@/plugins/useFlash';
import FlashMessageRender from '@/components/FlashMessageRender';
import getServerStartup from '@/api/swr/getServerStartup';
import Select from '@/components/elements/Select';
import isEqual from 'react-fast-compare';
import { ServerContext } from '@/state/server';

interface Props {
    variable: ServerEggVariable; // Переменная сервера
}

const VariableBox = ({ variable }: Props) => {
    const FLASH_KEY = `server:startup:${variable.envVariable}`; // Ключ для сообщений об ошибках

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid); // Получаем UUID сервера
    const [loading, setLoading] = useState(false); // Состояние загрузки
    const [canEdit] = usePermissions(['startup.update']); // Проверяем права доступа на редактирование
    const { clearFlashes, clearAndAddHttpError } = useFlash(); // Функции для работы с сообщениями об ошибках
    const { mutate } = getServerStartup(uuid); // Получаем функцию мутации для обновления данных сервера

    // Функция для обновления значения переменной
    const setVariableValue = debounce((value: string) => {
        setLoading(true); // Устанавливаем состояние загрузки
        clearFlashes(FLASH_KEY); // Очищаем старые сообщения об ошибках

        updateStartupVariable(uuid, variable.envVariable, value) // Запрос на обновление переменной
            .then(([response, invocation]) =>
                mutate(
                    (data) => ({
                        ...data,
                        invocation,
                        variables: (data.variables || []).map((v) =>
                            v.envVariable === response.envVariable ? response : v // Обновляем переменные
                        ),
                    }),
                    false
                )
            )
            .catch((error) => {
                console.error(error); // Логируем ошибку
                clearAndAddHttpError({ error, key: FLASH_KEY }); // Обрабатываем ошибку
            })
            .then(() => setLoading(false)); // Сбрасываем состояние загрузки
    }, 500);

    // Проверяем, используется ли переключатель
    const useSwitch = variable.rules.some(
        (v) => v === 'boolean' || v === 'in:0,1' || v === 'in:1,0' || v === 'in:true,false' || v === 'in:false,true'
    );
    const isStringSwitch = variable.rules.some((v) => v === 'string'); // Проверяем, является ли переменная строкой
    const selectValues = variable.rules.find((v) => v.startsWith('in:'))?.split(',') || []; // Получаем значения для выбора

    return (
        <TitledGreyBox
            title={
                <p className="text-sm uppercase">
                    {!variable.isEditable && (
                        <span className="bg-neutral-700 text-xs py-1 px-2 rounded-full mr-2 mb-1">Только для чтения</span> // Текст для недоступных переменных
                    )}
                    {variable.name} // Название переменной
                </p>
            }
        >
            <FlashMessageRender byKey={FLASH_KEY} className="mb-2 md:mb-4" /> // Отображение сообщений об ошибках
            <InputSpinner visible={loading}> {/* Спиннер загрузки */}
                {useSwitch ? (
                    <>
                        <Switch
                            readOnly={!canEdit || !variable.isEditable} // Переключатель доступности
                            name={variable.envVariable} // Имя переменной
                            defaultChecked={
                                isStringSwitch ? variable.serverValue === 'true' : variable.serverValue === '1' // Значение по умолчанию для переключателя
                            }
                            onChange={() => {
                                if (canEdit && variable.isEditable) {
                                    if (isStringSwitch) {
                                        setVariableValue(variable.serverValue === 'true' ? 'false' : 'true'); // Меняем значение для строкового переключателя
                                    } else {
                                        setVariableValue(variable.serverValue === '1' ? '0' : '1'); // Меняем значение для обычного переключателя
                                    }
                                }
                            }}
                        />
                    </>
                ) : (
                    <>
                        {selectValues.length > 0 ? (
                            <>
                                <Select
                                    onChange={(e) => setVariableValue(e.target.value)} // Обработчик изменения значения
                                    name={variable.envVariable}
                                    defaultValue={variable.serverValue ?? variable.defaultValue} // Значение по умолчанию
                                    disabled={!canEdit || !variable.isEditable} // Доступность выбора
                                >
                                    {selectValues.map((selectValue) => (
                                        <option
                                            key={selectValue.replace('in:', '')} // Уникальный ключ для значений
                                            value={selectValue.replace('in:', '')} // Значение для выбора
                                        >
                                            {selectValue.replace('in:', '')} // Отображаемое значение
                                        </option>
                                    ))}
                                </Select>
                            </>
                        ) : (
                            <>
                                <Input
                                    onKeyUp={(e) => {
                                        if (canEdit && variable.isEditable) {
                                            setVariableValue(e.currentTarget.value); // Обновляем значение при нажатии клавиши
                                        }
                                    }}
                                    readOnly={!canEdit || !variable.isEditable} // Доступность ввода
                                    name={variable.envVariable}
                                    defaultValue={variable.serverValue ?? ''} // Значение по умолчанию
                                    placeholder={variable.defaultValue} // Подсказка
                                />
                            </>
                        )}
                    </>
                )}
            </InputSpinner>

            <p className="mt-1 text-xs text-neutral-300">
                {variable.description} // Описание переменной
            </p>
        </TitledGreyBox>
    );
};

export default memo(VariableBox, isEqual); // Экспортируем компонент с мемоизацией
