import { ServerContext } from '@/state/server';
import { SocketEvent } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';

const TransferListener = () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid); // Получение UUID сервера
    const getServer = ServerContext.useStoreActions((actions) => actions.server.getServer); // Действие для получения информации о сервере
    const setServerFromState = ServerContext.useStoreActions((actions) => actions.server.setServerFromState); // Действие для обновления состояния сервера

    // Подписка на событие статуса передачи, чтобы обновить состояние сервера
    useWebsocketEvent(SocketEvent.TRANSFER_STATUS, (status: string) => {
        if (status === 'pending' || status === 'processing') {
            // Если статус "ожидание" или "обработка", установить состояние передачи
            setServerFromState((s) => ({ ...s, isTransferring: true }));
            return;
        }

        if (status === 'failed') {
            // Если статус "неудача", установить состояние передачи в false
            setServerFromState((s) => ({ ...s, isTransferring: false }));
            return;
        }

        if (status !== 'completed') {
            return; // Если статус не "завершено", ничего не делать
        }

        // Обновить информацию о сервере, так как его узел и выделения были обновлены
        getServer(uuid).catch((error) => console.error(error)); // Обработка ошибки при получении информации о сервере
    });

    return null; // Компонент ничего не рендерит
};

export default TransferListener; // Экспорт компонента
