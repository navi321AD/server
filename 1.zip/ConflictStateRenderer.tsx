import React from 'react';
import { ServerContext } from '@/state/server';
import ScreenBlock from '@/components/elements/ScreenBlock';
import ServerInstallSvg from '@/assets/images/server_installing.svg';
import ServerErrorSvg from '@/assets/images/server_error.svg';
import ServerRestoreSvg from '@/assets/images/server_restore.svg';

export default () => {
    const status = ServerContext.useStoreState((state) => state.server.data?.status || null); // Получаем статус сервера
    const isTransferring = ServerContext.useStoreState((state) => state.server.data?.isTransferring || false); // Проверяем, идет ли передача
    const isNodeUnderMaintenance = ServerContext.useStoreState(
        (state) => state.server.data?.isNodeUnderMaintenance || false // Проверяем, находится ли узел на обслуживании
    );

    return status === 'installing' || status === 'install_failed' || status === 'reinstall_failed' ? (
        <ScreenBlock
            title={'Запуск установщика'} // Заголовок для установки
            image={ServerInstallSvg} // Изображение для установки
            message={'Ваш сервер скоро будет готов, пожалуйста, попробуйте снова через несколько минут.'} // Сообщение для пользователя
        />
    ) : status === 'suspended' ? (
        <ScreenBlock
            title={'Сервер приостановлен'} // Заголовок для приостановленного сервера
            image={ServerErrorSvg} // Изображение ошибки
            message={'Этот сервер приостановлен и недоступен.'} // Сообщение о недоступности
        />
    ) : isNodeUnderMaintenance ? (
        <ScreenBlock
            title={'Узел на обслуживании'} // Заголовок для узла на обслуживании
            image={ServerErrorSvg} // Изображение ошибки
            message={'Узел этого сервера в настоящее время находится на обслуживании.'} // Сообщение о обслуживании
        />
    ) : (
        <ScreenBlock
            title={isTransferring ? 'Передача' : 'Восстановление из резервной копии'} // Заголовок для передачи или восстановления
            image={ServerRestoreSvg} // Изображение восстановления
            message={
                isTransferring
                    ? 'Ваш сервер передается на новый узел, пожалуйста, проверьте позже.' // Сообщение для передачи
                    : 'Ваш сервер в настоящее время восстанавливается из резервной копии, пожалуйста, проверьте через несколько минут.' // Сообщение для восстановления
            }
        />
    );
};
