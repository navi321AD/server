import React, { useEffect, useState } from 'react'; // Импортирование необходимых библиотек и хуков
import { Websocket } from '@/plugins/Websocket'; // Импортирование класса Websocket
import { ServerContext } from '@/state/server'; // Импортирование контекста сервера
import getWebsocketToken from '@/api/server/getWebsocketToken'; // Импортирование функции для получения токена вебсокета
import ContentContainer from '@/components/elements/ContentContainer'; // Импортирование контейнера для содержимого
import { CSSTransition } from 'react-transition-group'; // Импортирование компонента для анимаций
import Spinner from '@/components/elements/Spinner'; // Импортирование компонента загрузки
import tw from 'twin.macro'; // Импортирование библиотеки для использования Tailwind CSS в Styled Components

const reconnectErrors = ['jwt: exp claim is invalid', 'jwt: created too far in past (denylist)']; // Ошибки, при которых нужно пытаться переподключиться

export default () => {
    let updatingToken = false; // Флаг, чтобы избежать обновления токена, пока оно уже выполняется
    const [error, setError] = useState<'connecting' | string>(''); // Состояние для хранения ошибок
    const { connected, instance } = ServerContext.useStoreState((state) => state.socket); // Получение состояния подключения вебсокета
    const uuid = ServerContext.useStoreState((state) => state.server.data?.uuid); // Получение UUID сервера
    const setServerStatus = ServerContext.useStoreActions((actions) => actions.status.setServerStatus); // Действие для установки статуса сервера
    const { setInstance, setConnectionState } = ServerContext.useStoreActions((actions) => actions.socket); // Действия для установки экземпляра и состояния соединения

    // Функция для обновления токена
    const updateToken = (uuid: string, socket: Websocket) => {
        if (updatingToken) return; // Если токен уже обновляется, выходим

        updatingToken = true; // Устанавливаем флаг, что токен обновляется
        getWebsocketToken(uuid) // Получение нового токена
            .then((data) => socket.setToken(data.token, true)) // Установка токена в сокет
            .catch((error) => console.error(error)) // Обработка ошибок
            .then(() => {
                updatingToken = false; // Сброс флага обновления токена
            });
    };

    // Функция для подключения к вебсокету
    const connect = (uuid: string) => {
        const socket = new Websocket(); // Создание нового экземпляра вебсокета

        // Обработка событий сокета
        socket.on('auth success', () => setConnectionState(true)); // Успешная аутентификация
        socket.on('SOCKET_CLOSE', () => setConnectionState(false)); // Закрытие сокета
        socket.on('SOCKET_ERROR', () => {
            setError('connecting'); // Установка состояния ошибки при проблемах с соединением
            setConnectionState(false);
        });
        socket.on('status', (status) => setServerStatus(status)); // Обновление статуса сервера

        socket.on('daemon error', (message) => {
            console.warn('Получено сообщение об ошибке от демона сокета:', message); // Логирование ошибок демона
        });

        socket.on('token expiring', () => updateToken(uuid, socket)); // Обновление токена перед его истечением
        socket.on('token expired', () => updateToken(uuid, socket)); // Обновление токена после его истечения
        socket.on('jwt error', (error: string) => {
            setConnectionState(false); // Установка состояния соединения в false
            console.warn('Ошибка проверки JWT от wings:', error); // Логирование ошибки JWT

            // Проверка на ошибки, требующие переподключения
            if (reconnectErrors.find((v) => error.toLowerCase().indexOf(v) >= 0)) {
                updateToken(uuid, socket); // Попытка обновления токена
            } else {
                setError(
                    'Произошла ошибка при проверке предоставленных учетных данных для вебсокета. Пожалуйста, обновите страницу.'
                );
            }
        });

        socket.on('transfer status', (status: string) => {
            if (status === 'starting' || status === 'success') {
                return; // Если статус передачи 'starting' или 'success', ничего не делаем
            }

            // Закрытие сокета и попытка переподключения
            socket.close();
            setError('connecting'); // Установка состояния ошибки при переподключении
            setConnectionState(false);
            setInstance(null); // Удаление текущего экземпляра сокета
            connect(uuid); // Попытка повторного подключения
        });

        getWebsocketToken(uuid) // Получение токена вебсокета
            .then((data) => {
                // Установка токена и подключение
                socket.setToken(data.token).connect(data.socket);
                setInstance(socket); // Установка нового экземпляра сокета
            })
            .catch((error) => console.error(error)); // Обработка ошибок
    };

    // Эффект для очистки ошибки при успешном соединении
    useEffect(() => {
        connected && setError('');
    }, [connected]);

    // Эффект для закрытия экземпляра сокета при размонтировании
    useEffect(() => {
        return () => {
            instance && instance.close();
        };
    }, [instance]);

    // Эффект для подключения к вебсокету, если нет экземпляра или UUID
    useEffect(() => {
        if (instance || !uuid) {
            return; // Если экземпляр уже существует или UUID отсутствует, выходим
        }

        connect(uuid); // Подключение
    }, [uuid]);

    // Отображение ошибки, если она существует
    return error ? (
        <CSSTransition timeout={150} in appear classNames={'fade'}>
            <div css={tw`bg-red-500 py-2`}>
                <ContentContainer css={tw`flex items-center justify-center`}>
                    {error === 'connecting' ? (
                        <>
                            <Spinner size={'small'} /> {/* Компонент загрузки */}
                            <p css={tw`ml-2 text-sm text-red-100`}>
                                У нас возникли проблемы с подключением к вашему серверу, пожалуйста, подождите...
                            </p>
                        </>
                    ) : (
                        <p css={tw`ml-2 text-sm text-white`}>{error}</p> // Отображение сообщения об ошибке
                    )}
                </ContentContainer>
            </div>
        </CSSTransition>
    ) : null; // Если ошибок нет, возвращаем null
};
