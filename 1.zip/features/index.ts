import { ComponentType, lazy } from 'react';

/**
 * Пользовательские функции должны быть зарегистрированы здесь как ленивые компоненты, чтобы они
 * не влияли на размер сгенерированного JS пакета. Они будут автоматически загружаться
 * только тогда, когда они фактически потребуются клиенту (что может и не произойти, в зависимости
 * от функции и яйца).
 */
const features: Record<string, ComponentType> = {
    eula: lazy(() => import('@feature/eula/EulaModalFeature')),
    java_version: lazy(() => import('@feature/JavaVersionModalFeature')),
    gsl_token: lazy(() => import('@feature/GSLTokenModalFeature')),
    pid_limit: lazy(() => import('@feature/PIDLimitModalFeature')),
    steam_disk_space: lazy(() => import('@feature/SteamDiskSpaceFeature')),
};

export default features;
