import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import Modal from '@/components/elements/Modal';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import FlashMessageRender from '@/components/FlashMessageRender';
import useFlash from '@/plugins/useFlash';
import { SocketEvent } from '@/components/server/events';
import { useStoreState } from 'easy-peasy';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';

const PIDLimitModalFeature = () => {
    const [visible, setVisible] = useState(false); // Состояние для видимости модального окна
    const [loading] = useState(false); // Состояние загрузки

    const status = ServerContext.useStoreState((state) => state.status.value); // Получаем статус сервера
    const { clearFlashes } = useFlash(); // Функция для очистки сообщений
    const { connected, instance } = ServerContext.useStoreState((state) => state.socket); // Получаем состояние сокета
    const isAdmin = useStoreState((state) => state.user.data!.rootAdmin); // Проверяем, является ли пользователь администратором

    useEffect(() => {
        if (!connected || !instance || status === 'running') return; // Проверяем соединение и статус сервера

        const errors = [ // Массив ошибок, которые будут вызывать появление модального окна
            'pthread_create failed',
            'failed to create thread',
            'unable to create thread',
            'unable to create native thread',
            'unable to create new native thread',
            'exception in thread "craft async scheduler management thread"',
        ];

        const listener = (line: string) => { // Функция-слушатель для вывода консоли
            if (errors.some((p) => line.toLowerCase().includes(p))) {
                setVisible(true); // Показываем модальное окно, если ошибка обнаружена
            }
        };

        instance.addListener(SocketEvent.CONSOLE_OUTPUT, listener); // Добавляем слушатель события

        return () => {
            instance.removeListener(SocketEvent.CONSOLE_OUTPUT, listener); // Удаляем слушатель при размонтировании
        };
    }, [connected, instance, status]);

    useEffect(() => {
        clearFlashes('feature:pidLimit'); // Очищаем сообщения при монтировании компонента
    }, []);

    return (
        <Modal
            visible={visible} // Управляем видимостью модального окна
            onDismissed={() => setVisible(false)} // Закрываем модальное окно
            closeOnBackground={false}
            showSpinnerOverlay={loading} // Показываем индикатор загрузки
        >
            <FlashMessageRender key={'feature:pidLimit'} css={tw`mb-4`} />
            {isAdmin ? ( // Условное отображение для администратора
                <>
                    <div css={tw`mt-4 sm:flex items-center`}>
                        <FontAwesomeIcon css={tw`pr-4`} icon={faExclamationTriangle} color={'orange'} size={'4x'} />
                        <h2 css={tw`text-2xl mb-4 text-neutral-100 `}>Достигнут предел памяти или процессов...</h2>
                    </div>
                    <p css={tw`mt-4`}>Этот сервер достиг максимального предела процессов или памяти.</p>
                    <p css={tw`mt-4`}>
                        Увеличение <code css={tw`font-mono bg-neutral-900`}>container_pid_limit</code> в конфигурации wings,
                        <code css={tw`font-mono bg-neutral-900`}>config.yml</code>, может помочь решить
                        эту проблему.
                    </p>
                    <p css={tw`mt-4`}>
                        <b>Примечание: Wings необходимо перезапустить для применения изменений в конфигурационном файле</b>
                    </p>
                    <div css={tw`mt-8 sm:flex items-center justify-end`}>
                        <Button onClick={() => setVisible(false)} css={tw`w-full sm:w-auto border-transparent`}>
                            Закрыть
                        </Button>
                    </div>
                </>
            ) : ( // Условное отображение для неадминистратора
                <>
                    <div css={tw`mt-4 sm:flex items-center`}>
                        <FontAwesomeIcon css={tw`pr-4`} icon={faExclamationTriangle} color={'orange'} size={'4x'} />
                        <h2 css={tw`text-2xl mb-4 text-neutral-100`}>Достигнут возможный предел ресурсов...</h2>
                    </div>
                    <p css={tw`mt-4`}>
                        Этот сервер пытается использовать больше ресурсов, чем выделено. Пожалуйста, свяжитесь с администратором
                        и предоставьте им следующую ошибку.
                    </p>
                    <p css={tw`mt-4`}>
                        <code css={tw`font-mono bg-neutral-900`}>
                            pthread_create failed, Возможно, недостаточно памяти или достигнут предел процессов/ресурсов
                        </code>
                    </p>
                    <div css={tw`mt-8 sm:flex items-center justify-end`}>
                        <Button onClick={() => setVisible(false)} css={tw`w-full sm:w-auto border-transparent`}>
                            Закрыть
                        </Button>
                    </div>
                </>
            )}
        </Modal>
    );
};

export default PIDLimitModalFeature; // Экспортируем компонент
