import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import Modal from '@/components/elements/Modal';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import FlashMessageRender from '@/components/FlashMessageRender';
import useFlash from '@/plugins/useFlash';
import { SocketEvent } from '@/components/server/events';
import { useStoreState } from 'easy-peasy';

const SteamDiskSpaceFeature = () => {
    const [visible, setVisible] = useState(false); // Состояние для видимости модального окна
    const [loading] = useState(false); // Состояние загрузки

    const status = ServerContext.useStoreState((state) => state.status.value); // Получаем статус сервера
    const { clearFlashes } = useFlash(); // Функция для очистки сообщений
    const { connected, instance } = ServerContext.useStoreState((state) => state.socket); // Получаем состояние сокета
    const isAdmin = useStoreState((state) => state.user.data!.rootAdmin); // Проверяем, является ли пользователь администратором

    useEffect(() => {
        if (!connected || !instance || status === 'running') return; // Проверяем соединение и статус сервера

        const errors = ['steamcmd needs 250mb of free disk space to update', '0x202 after update job']; // Сообщения об ошибках

        const listener = (line: string) => { // Функция-слушатель для вывода консоли
            if (errors.some((p) => line.toLowerCase().includes(p))) {
                setVisible(true); // Показываем модальное окно, если ошибка обнаружена
            }
        };

        instance.addListener(SocketEvent.CONSOLE_OUTPUT, listener); // Добавляем слушатель события

        return () => {
            instance.removeListener(SocketEvent.CONSOLE_OUTPUT, listener); // Удаляем слушатель при размонтировании
        };
    }, [connected, instance, status]);

    useEffect(() => {
        clearFlashes('feature:steamDiskSpace'); // Очищаем сообщения при монтировании компонента
    }, []);

    return (
        <Modal
            visible={visible} // Управляем видимостью модального окна
            onDismissed={() => setVisible(false)} // Закрываем модальное окно
            closeOnBackground={false}
            showSpinnerOverlay={loading} // Показываем индикатор загрузки
        >
            <FlashMessageRender key={'feature:steamDiskSpace'} css={tw`mb-4`} />
            {isAdmin ? ( // Условное отображение для администратора
                <>
                    <div css={tw`mt-4 sm:flex items-center`}>
                        <h2 css={tw`text-2xl mb-4 text-neutral-100 `}>Недостаточно доступного дискового пространства...</h2>
                    </div>
                    <p css={tw`mt-4`}>
                        На этом сервере недостаточно доступного дискового пространства, и он не может завершить процесс установки или обновления.
                    </p>
                    <p css={tw`mt-4`}>
                        Убедитесь, что на машине достаточно дискового пространства, выполнив команду{' '}
                        <code css={tw`font-mono bg-neutral-900 rounded py-1 px-2`}>df -h</code> на машине, которая хостит
                        этот сервер. Удалите файлы или увеличьте доступное дисковое пространство, чтобы решить проблему.
                    </p>
                    <div css={tw`mt-8 sm:flex items-center justify-end`}>
                        <Button onClick={() => setVisible(false)} css={tw`w-full sm:w-auto border-transparent`}>
                            Закрыть
                        </Button>
                    </div>
                </>
            ) : ( // Условное отображение для неадминистратора
                <>
                    <div css={tw`mt-4 sm:flex items-center`}>
                        <h2 css={tw`text-2xl mb-4 text-neutral-100`}>Недостаточно доступного дискового пространства...</h2>
                    </div>
                    <p css={tw`mt-4`}>
                        На этом сервере недостаточно доступного дискового пространства, и он не может завершить процесс установки или обновления. Пожалуйста, свяжитесь с администратором(ами) и сообщите им о проблемах с дисковым пространством.
                    </p>
                    <div css={tw`mt-8 sm:flex items-center justify-end`}>
                        <Button onClick={() => setVisible(false)} css={tw`w-full sm:w-auto border-transparent`}>
                            Закрыть
                        </Button>
                    </div>
                </>
            )}
        </Modal>
    );
};

export default SteamDiskSpaceFeature; // Экспортируем компонент
