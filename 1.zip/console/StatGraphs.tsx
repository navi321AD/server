import React, { useEffect, useRef } from 'react';
import { ServerContext } from '@/state/server'; // Импорт контекста сервера
import { SocketEvent } from '@/components/server/events'; // Импорт событий сокета
import useWebsocketEvent from '@/plugins/useWebsocketEvent'; // Хук для работы с событиями веб-сокетов
import { Line } from 'react-chartjs-2'; // Импорт компонента Line для графиков
import { useChart, useChartTickLabel } from '@/components/server/console/chart'; // Импорт хуков для графиков
import { hexToRgba } from '@/lib/helpers'; // Импорт функции для преобразования HEX в RGBA
import { bytesToString } from '@/lib/formatters'; // Импорт функции для форматирования байтов в строку
import { CloudDownloadIcon, CloudUploadIcon } from '@heroicons/react/solid'; // Импорт иконок
import { theme } from 'twin.macro'; // Импорт темы
import ChartBlock from '@/components/server/console/ChartBlock'; // Импорт компонента для блока графиков
import Tooltip from '@/components/elements/tooltip/Tooltip'; // Импорт компонента подсказки

export default () => {
    const status = ServerContext.useStoreState((state) => state.status.value); // Получение статуса сервера
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits); // Получение лимитов сервера
    const previous = useRef<Record<'tx' | 'rx', number>>({ tx: -1, rx: -1 }); // Хранение предыдущих значений для передачи и приема

    const cpu = useChartTickLabel('CPU', limits.cpu, '%', 2); // Хук для графика CPU
    const memory = useChartTickLabel('Memory', limits.memory, 'MiB'); // Хук для графика памяти
    const network = useChart('Network', {
        sets: 2,
        options: {
            scales: {
                y: {
                    ticks: {
                        callback(value) {
                            return bytesToString(typeof value === 'string' ? parseInt(value, 10) : value); // Форматирование значений на оси Y
                        },
                    },
                },
            },
        },
        callback(opts, index) {
            return {
                ...opts,
                label: !index ? 'Network In' : 'Network Out', // Подписи для графиков
                borderColor: !index ? theme('colors.cyan.400') : theme('colors.yellow.400'), // Цвет границ
                backgroundColor: hexToRgba(!index ? theme('colors.cyan.700') : theme('colors.yellow.700'), 0.5), // Цвет фона
            };
        },
    });

    useEffect(() => {
        if (status === 'offline') { // Очистка графиков при оффлайне
            cpu.clear();
            memory.clear();
            network.clear();
        }
    }, [status]);

    useWebsocketEvent(SocketEvent.STATS, (data: string) => { // Обработка события STATS
        let values: any = {};
        try {
            values = JSON.parse(data); // Парсинг данных
        } catch (e) {
            return;
        }
        cpu.push(values.cpu_absolute); // Добавление значений CPU
        memory.push(Math.floor(values.memory_bytes / 1024 / 1024)); // Добавление значений памяти
        network.push([
            previous.current.tx < 0 ? 0 : Math.max(0, values.network.tx_bytes - previous.current.tx), // Добавление входящих данных
            previous.current.rx < 0 ? 0 : Math.max(0, values.network.rx_bytes - previous.current.rx), // Добавление исходящих данных
        ]);

        previous.current = { tx: values.network.tx_bytes, rx: values.network.rx_bytes }; // Сохранение текущих значений
    });

    return (
        <>
            <ChartBlock title={'Нагрузка CPU'}> {/* Блок для графика CPU */}
                <Line {...cpu.props} />
            </ChartBlock>
            <ChartBlock title={'Память'}> {/* Блок для графика памяти */}
                <Line {...memory.props} />
            </ChartBlock>
            <ChartBlock
                title={'Сеть'} // Блок для графика сети
                legend={
                    <>
                        <Tooltip arrow content={'Входящие'}> {/* Подсказка для входящих данных */}
                            <CloudDownloadIcon className={'mr-2 w-4 h-4 text-yellow-400'} />
                        </Tooltip>
                        <Tooltip arrow content={'Исходящие'}> {/* Подсказка для исходящих данных */}
                            <CloudUploadIcon className={'w-4 h-4 text-cyan-400'} />
                        </Tooltip>
                    </>
                }
            >
                <Line {...network.props} />
            </ChartBlock>
        </>
    );
};
